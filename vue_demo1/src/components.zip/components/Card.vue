<!-- <script setup lang="ts">
  import { NSpace,NCard} from 'naive-ui'
</script>
<template>
  <n-space>
     <n-card title="卡片" hoverable size="huge">34124141
     </n-card>
  </n-space>
</template>


<style scoped>
.n-card {
  max-width: 300px;
  height: 300px;
  width: 2000px;
}
</style> -->