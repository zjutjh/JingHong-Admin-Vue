<script setup lang="ts">
  import { NSpace,NLayout} from 'naive-ui'
</script>
<template>
<n-space>
  <n-layout>
   主要内容
  </n-layout>
</n-space>
</template>

<style scoped>
.n-layout{
height:100%;
width: auto;
top: 80px;
position: absolute;
left: 13%;
right:0px;
background-color: aquamarine;
}
</style>